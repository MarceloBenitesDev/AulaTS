export class Estudante {
    private nome: string;
    private cpf: number;
    private endereco: string;
    private estadocivil: string;
    private turma: string;

    constructor(nome: string, cpf: number, endereco: string, estadocivil: string,
        turma: string
    ) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.estadocivil = estadocivil;
        this.turma = turma;
    }
}

import { Pessoa } from "./pessoa";

export class Aluno extends Pessoa{
    private turma: string = "";

    public falar(): string {
        return "São muitas provas, mimimi";
    }
}