export class FuncionarioProfessor {
    private nome: string;
    private cpf: number;
    private endereco: string;
    private estadocivil: string;
    private salario: number;
    private titulacao: string;

    constructor(
        nome: string, cpf: number, endereco: string, estadocivil: string,
        salario: number, titulacao: string
    ) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.estadocivil = estadocivil;
        this.salario = salario;
        this.titulacao = titulacao;
    }
}