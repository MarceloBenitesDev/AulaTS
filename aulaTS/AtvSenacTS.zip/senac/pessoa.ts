export class Pessoa {
    protected nome: string = "";
    protected cpf: string = "";
    protected endereco: string = "";
    protected estadocivil: string = "";

    constructor(
        nome: string, cpf: string, endereco: string, estadocivil: string
    ) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.estadocivil = estadocivil;
    }

    public falar(): string {
        return "Sou uma pessoa";
    }
}