export class FuncionarioAdm {
    private nome: string;
    private cpf: number;
    private endereco: string;
    private estadocivil: string;
    private salario: number;
    private setor: string;

    constructor(nome: string, cpf: number, endereco: string,
    estadocivil: string, salario: number, setor: string
    ) {
       this.nome = nome;
       this.cpf = cpf;
       this.endereco = endereco;
       this.estadocivil = estadocivil;
       this.salario = salario;
       this.setor = setor;
    }
}